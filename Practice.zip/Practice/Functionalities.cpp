#include "Functionalities.h"

void Create_Object(Container &data)
{
    data.emplace_back(
        std::make_shared<Hotel>("HILTON",60,50,Residental_Type::RENTAL)
    );
    data.emplace_back(
        std::make_shared<Hotel>("TAJ",65,10,Residental_Type::RENTAL)

    );

    data.emplace_back(
        std::make_shared<House>("Khanna'House",80,8,Residental_Type::OWN)
    );
    data.emplace_back(
        std::make_shared<House>("Harshit House",44,9,Residental_Type::OWN)
    );
}

void Display(const Container &data)
{
    for(const v_type_Pointer &v:data){
    std::visit(
        [&](auto&& val){
            std::cout<<*val<<"\n";
        },
        v
    );
    }
}

void ShowRoomsLeft(const Container &data)
{
    
    for(const v_type_Pointer& v :data){
        std::visit(
            [&](auto && v){
                v->Number_of_Rooms_left();
                
            },
            v
        );
    }
}

float Average_persons(const Container &data)
{
    float total=0;
    for(const v_type_Pointer& h:data){
        std::visit(
            [&](auto &&val){
                total=val->personsIn();

            },
            h
        );
    }
    return total/data.size();

}

std::vector<std::string> NameOfAllResident(const Container &data)
{
    std::vector<std::string> vec;
    for(const v_type_Pointer& v:data){
        std::visit(
            [&](auto&& hp){
                vec.emplace_back(hp.get()->name());
            },
            v
        );
    }
    
    if(vec.empty()){
        throw std::nullopt;
    }
    return vec;
}
