#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include"Hotel.h"
#include"House.h"
#include<memory>
#include<variant>
#include<vector>
#include<thread>
#include<optional>
#include<functional>
#include<algorithm>

using Hotel_Pointer=std::shared_ptr<Hotel>;
using House_Pointer=std::shared_ptr<House>;

using House_Container=std::vector<House_Pointer>;

using v_type_Pointer=std::variant<Hotel_Pointer,House_Pointer>;
using Container=std::vector<v_type_Pointer>;

void Create_Object(Container& data);

void Display(const Container& data);

void ShowRoomsLeft(const Container& data);

template<typename T>
std::optional<std::vector<v_type_Pointer> > Sametypeinstance(const Container &data,T type);


float Average_persons(const Container& data);

std::vector<std::string> NameOfAllResident(const Container& data);
#endif // FUNCTIONALITIES_H

template <typename T>
inline std::optional<std::vector<v_type_Pointer>> Sametypeinstance(const Container &data, T type)
{
    Container res;
    for(const v_type_Pointer& v:data){
        std::visit(
            [&](auto&& val){
                if(val->type()==type)
                    res.emplace_back(val);
            },
            v
        );
    }
    return res;

}
