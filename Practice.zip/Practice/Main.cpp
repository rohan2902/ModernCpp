#include<iostream>
#include"Functionalities.h"
#include<array>

int main(){

    
    Container data;

    // std::array<std::thread,4> arr;
    // Create_Object(data);

    // arr[0]=std::thread (
    // &Create_Object,std::ref(data)
    // );

    // arr[0].join();

    // arr[1]=std::thread (&Display,std::ref(data));

    // arr[2]=std::thread (&ShowRoomsLeft,std::ref(data));

    

    // for(std::thread &t:arr){
    //     if(t.joinable()){
    //         t.join();
    //     }
    // }
    Create_Object(data);
    Display(std::ref(data));
    ShowRoomsLeft(std::ref(data));

    std::optional<Container> res=Sametypeinstance(std::ref(data),Residental_Type::OWN);

    for(auto && v:res.value()){
        std::visit(
            [&](auto &&val){
                std::cout<<*val<<std::endl;
            }
            ,v
        );

    }

    float ans=Average_persons(std::ref(data));
    
    std::cout<<"Average of persons : "<<ans<<std::endl;

    try{
    std::cout<<"\n\nAll House name : ";
    auto str_ans=NameOfAllResident(std::ref(data));
    for(auto&& v:str_ans){
        std::cout<<v<<" ";
    }
    }
    catch(std::runtime_error &mess){
        std::cout<<mess.what();
    }


    
    
}