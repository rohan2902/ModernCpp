
#ifndef HOUSE_H
#define HOUSE_H

#include<iostream>
#include"Residental_type.h"
class House
{
private:
    /* data */
    std::string _name;
    int _rooms;
    int _persons_in;
    Residental_Type _type;


public:
    // House(/* args */) {}
    // House(const House&)=delete;
    // House(House&&)=delete;
    ~House() {}

    void Number_of_Rooms_left(){
        int person=_persons_in;
        int room_left=_rooms;
        while(person!=0){
            person-=4;
            room_left--;
        }
    std::cout<<"\nRoom_left in house:"<<room_left;
    // std::cout<<"\n hotel wala working mai hai";
    };
    
    House(std::string name,
    int rooms,
    int persons_in,
    Residental_Type type);

    std::string name() const { return _name; }

    int rooms() const { return _rooms; }

    int personsIn() const { return _persons_in; }

    Residental_Type type() const { return _type; }

    friend std::ostream &operator<<(std::ostream &os, const House &rhs);

    
};



#endif // HOUSE_H
