#include "House.h"

House::House(std::string name, int rooms, int persons_in, Residental_Type type)
:_name(name),_rooms(rooms),_persons_in(persons_in),_type(type){
}
std::ostream &operator<<(std::ostream &os, const House &rhs) {
    os << "_name: " << rhs._name
       << " _rooms: " << rhs._rooms
       << " _persons_in: " << rhs._persons_in
       << " _type: " << static_cast<int>(rhs._type);
    return os;
}
