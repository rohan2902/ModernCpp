#ifndef HOTEL_H
#define HOTEL_H
#include<iostream>
#include"Residental_type.h"
class Hotel
{
private:
    /* data */
    std::string _name;
    int _rooms;
    int _persons_in;
    Residental_Type _type;

    

public:
    // Hotel(/* args */) =delete;
    // Hotel(const Hotel&)=delete;
    // Hotel(Hotel&&)=delete;


    ~Hotel() {}

    void Number_of_Rooms_left(){
        int person=_persons_in;
        int room_left=_rooms;
        while(person!=0){
            person-=2;
            room_left--;
        
        }
    std::cout<<"\nRoom_left in Hotel:"<<room_left;
    // std::cout<<"\n hotel wala working mai hai";
    };

    Hotel(std::string name,
    int rooms,
    int persons_in,
    Residental_Type type);

    std::string name() const { return _name; }

    int rooms() const { return _rooms; }

    int personsIn() const { return _persons_in; }

    Residental_Type type() const { return _type; }

    friend std::ostream &operator<<(std::ostream &os, const Hotel &rhs);

    
};

#endif // HOTEL_H
