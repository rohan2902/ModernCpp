#ifndef RESIDENTAL_TYPE_H
#define RESIDENTAL_TYPE_H

enum class Residental_Type{
    OWN, RENTAL
};

#endif // RESIDENTAL_TYPE_H
