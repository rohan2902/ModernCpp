#include <iostream>
#include "Functionalities.h"

int main()
{
    Container data;
    CreateObjects(data);

    try
    {
        std::cout << HorsepowerWithGivenID(data, "112");
    }
    catch (std::runtime_error e)
    {
        std::cout << e.what();
    }

    try
    {
        Container ans = TorqueOver80(data);
        for (Pointer &ptr : ans)
        {
            std::cout << "\n"
                      << *ptr;
        }
    }
    catch (std::runtime_error e)
    {
        std::cout << e.what();
    }

    try
    {
        Container ans = FindEngineInstances(data, CarType::SPORTS);
        for (Pointer &ptr : ans)
        {
            std::cout << "\n"
                      << *ptr->engine();
        }
    }
    catch (std::runtime_error e)
    {
        std::cout << e.what();
    }

    try
    {
        {
            std::cout << "\n"
                      << CarIdWithLowestPrice(data);
        }
    }
    catch (std::runtime_error e)
    {
        std::cout << e.what();
    }

    try
    {
        {
            std::cout << "\n"
                      << FindAverageHorsepower(data);
        }
    }
    catch (std::runtime_error e)
    {
        std::cout << e.what();
    }

    std::cout << "\n"
              << Accept(data[0], data[3]);
}