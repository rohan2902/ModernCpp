#include "Car.h"

Car::Car(std::string CarID, std::string CarBrand, CarType type, std::shared_ptr<Engine> engine, float CarPrice)
:_CarId(CarID),_CarBrand(CarBrand), _type(type), _engine(engine),_CarPrice(CarPrice)
{
    
}


std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "\n \n Car Id: " << rhs._CarId
       << "\n Car Brand: " << rhs._CarBrand
       << "\n Type: " << static_cast<int>(rhs._type)
       << "\n Engine: " << *rhs._engine
       << "\n Car Price: " << rhs._CarPrice;
    return os;
}
