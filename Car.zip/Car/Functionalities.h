#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include <memory>
#include <vector>
#include "Car.h"

using Pointer = std::shared_ptr<Car>;
using Container = std::vector<Pointer>;

void CreateObjects(Container& data);

/*
    A function to find and return the horsepower of engine instance for a car
    whose id is provided as an argument
*/
int HorsepowerWithGivenID(Container& data , std::string id);

/*
    A function to find and return all instances of car whose engine torque
    is over 80 newton meters
*/
Container TorqueOver80(Container& data);

/*
    A function to find and engine instances of all cars whose cartype match with
    type provided in the argument
*/
Container FindEngineInstances(Container& data, enum CarType type);

/*
    A functin to find car id with lowest price
*/
std::string CarIdWithLowestPrice(Container& data);

/*
    A function to find average horsepower of all car instances satisfying 
    -engine type should be ICT
    - car price is over 1000000
*/
float FindAverageHorsepower(Container& data);

/*
    A function that accepts reference or pointers to 2 instances of car 
    and returns combined price
 */
float Accept(Pointer& p1, Pointer& p2);

#endif // FUNCTIONALITIES_H
