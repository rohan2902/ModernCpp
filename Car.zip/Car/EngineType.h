#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType
{
    ICT,
    HYBRID
};

#endif // ENGINETYPE_H
