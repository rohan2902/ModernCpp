#ifndef CAR_H
#define CAR_H

#include <iostream>
#include "CarType.h"
#include "Engine.h"
#include <memory>

class Car
{
private:
    std::string _CarId;
    std::string _CarBrand;
    CarType _type;
    std::shared_ptr<Engine> _engine;
    float _CarPrice;

public:
    Car() = default;
    Car(std::string CarID, std::string CarBrand, CarType type, std::shared_ptr<Engine> engine, float CarPrice);
    Car(const Car &) = delete;
    Car &operator=(const Car &) = delete;
    Car(Car &&) = delete;
    Car &operator=(Car &&) = delete;
    ~Car() = default;

    std::string carId() const { return _CarId; }

    std::string carBrand() const { return _CarBrand; }

    CarType type() const { return _type; }

    std::shared_ptr<Engine> engine() const { return _engine; }

    float carPrice() const { return _CarPrice; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);

    
};

#endif // CAR_H
