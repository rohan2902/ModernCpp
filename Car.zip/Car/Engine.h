#ifndef ENGINE_H
#define ENGINE_H

#include <iostream>
#include "EngineType.h"

class Engine
{
private:
    std::string _EngineNumber;
    EngineType _etype;
    int _EngineHorsepower;
    int _EngineTorque;

public:
    Engine() = default;
    Engine(std::string EngineNumber, EngineType etype, int Horsepower, int Torque );
    Engine(const Engine &) = delete;
    Engine &operator=(const Engine &) = delete;
    Engine(Engine &&) = delete;
    Engine &operator=(Engine &&) = delete;
    ~Engine() = default;

    std::string engineNumber() const { return _EngineNumber; }

    EngineType etype() const { return _etype; }

    int engineHorsepower() const { return _EngineHorsepower; }

    int engineTorque() const { return _EngineTorque; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);

};

#endif // ENGINE_H
