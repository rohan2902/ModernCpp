#include "Engine.h"

Engine::Engine(std::string EngineNumber, EngineType etype, int Horsepower, int Torque)
:_EngineNumber(EngineNumber), _etype(etype),_EngineHorsepower(Horsepower), _EngineTorque(Torque)
{

}


std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "\n Engine Number: " << rhs._EngineNumber
       << "\n Engine type: " <<static_cast<int>( rhs._etype)
       << "\n Engine Horsepower: " << rhs._EngineHorsepower
       << "\n Engine Torque: " << rhs._EngineTorque;
    return os;
}
