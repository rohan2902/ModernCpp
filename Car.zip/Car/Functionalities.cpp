#include "Functionalities.h"

void CreateObjects(Container &data)
{
    data.emplace_back(
        std::make_shared<Car>(
            "111",
            "Honda",
            CarType::SUV,
            std::make_shared<Engine>("101", EngineType::ICT, 70, 100),
            2000000.0f));

    data.emplace_back(
        std::make_shared<Car>(
            "112",
            "BMW",
            CarType::SEDAN,
            std::make_shared<Engine>("102", EngineType::HYBRID, 60, 50),
            6000000.0f));

    data.emplace_back(
        std::make_shared<Car>(
            "113",
            "AUDI",
            CarType::HATCHBACK,
            std::make_shared<Engine>("103", EngineType::ICT, 65, 85),
            4800000.0f));

    data.emplace_back(
        std::make_shared<Car>(
            "114",
            "JAGUAR",
            CarType::SPORTS,
            std::make_shared<Engine>("104", EngineType::HYBRID, 90, 70),
            9700000.0f));
}

int HorsepowerWithGivenID(Container &data, std::string id)
{
    if (data.empty())
    {
        throw std::runtime_error("\n Data is empty");
    }

    for (Pointer &ptr : data)
    {
        if (ptr->carId() == id)
        {
            return ptr->engine()->engineHorsepower();
        }
    }
    throw std::runtime_error("\n ID NOT FOUND");
}

Container TorqueOver80(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("\n Data is empty");
    }

    Container result;
    for (Pointer &ptr : data)
    {
        if (ptr->engine()->engineTorque() > 80)
        {
            result.emplace_back(ptr);
        }
    }

    if (result.empty())
    {
        throw std::runtime_error("\n Torque over 80 does not exist");
    }
    return result;
}

std::string CarIdWithLowestPrice(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("\n Data is empty");
    }

    auto itr = data.begin();
    auto min = (*itr)->carPrice();
    for (Pointer &ptr : data)

    {
        if (ptr->carPrice() < min)
        {
            min = ptr->carPrice();
        }
    }
    return (*itr)->carId();
}

float FindAverageHorsepower(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("\n Data is empty");
    }

    float total = 0.0f;
    int count = 0;
    for (Pointer &ptr : data)
    {

        if (ptr->engine()->etype() == EngineType::ICT && ptr->carPrice() > 1000000)
        {
            total = total + ptr->engine()->engineHorsepower();
            count++;
        }
    }
    return total / count;
    throw std::runtime_error("Engine type ICT not present or price is less 1000000");
}

float Accept(Pointer& p1, Pointer& p2)
{
    return p1->carPrice() + p2->carPrice();
}

Container FindEngineInstances(Container &data, CarType type)
{
    if (data.empty())
    {
        throw std::runtime_error("\n Data is empty");
    }

    Container result;
    for (Pointer &ptr : data)
    {
        if (ptr->type() == type)
        {
            result.emplace_back(ptr);
        }
    }

    if (result.empty())
    {
        throw std::runtime_error("\n Car with this type does not exist");
    }
    return result;
}
