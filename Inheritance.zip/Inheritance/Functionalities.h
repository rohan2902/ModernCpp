#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<memory>
#include<vector>
#include "Vehicle.h"

//create an alias which is an alternate name 
//for std::shared_ptr to vehicle
using Pointer=std::shared_ptr<Vehicle>;

//now specify alternate container which indicates
//a standard vector of "Pointer" where Pointer is explained above
using Container=std::vector<Pointer>;


void CreateObjects(Container&data);
float AveragePrice(Container&data);


#endif // FUNCTIONALITIES_H
