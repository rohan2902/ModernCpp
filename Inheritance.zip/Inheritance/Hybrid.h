#ifndef HYBRID_H
#define HYBRID_H

#include "Vehicle.h"
#include <ostream>
class Hybrid:public Vehicle
{
private:
    int _range;
public:
    Hybrid(int id,std::string name,float price,VehicleType type,int capacity);
    Hybrid(int id,std::string name,VehicleType type,int capacity);

    Hybrid()=default;
    Hybrid(const Hybrid&)=delete;
    Hybrid& operator=(const Hybrid&)=delete;
    Hybrid(Hybrid&&)=delete;
    Hybrid& operator=(Hybrid&&)=delete;

    ~Hybrid()=default;

    friend std::ostream &operator<<(std::ostream &os, const Hybrid &rhs);

};


#endif // HYBRID_H
