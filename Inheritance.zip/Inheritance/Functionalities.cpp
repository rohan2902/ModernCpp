#include "Functionalities.h"
#include "PetrolCar.h"
#include "DieselCar.h"
#include "EvCar.h"
#include "Hybrid.h"
void CreateObjects(Container &data)
{
    //step 1: Make a constructor call to petrolcar
    // std::make_shared<PetrolCar>(101,"City",1400000,VehicleType::PERSONAL,43);

    //step 2: 
//    std::shared_ptr<Vehicle>ptr = std::make_shared<PetrolCar>(101,"City",1400000,VehicleType::PERSONAL,43);

    data.emplace_back(std::make_shared<PetrolCar>(101,"Verna",100,VehicleType::PERSONAL,43));
    data.emplace_back(std::make_shared<PetrolCar>(102,"Dzire",200,VehicleType::PERSONAL,20));
    data.emplace_back(std::make_shared<PetrolCar>(103,"Fortuner",12200,VehicleType::PERSONAL,49));

    data.emplace_back(std::make_shared<DieselCar>(104,"Indigo",12999,VehicleType::PERSONAL,35));
    data.emplace_back(std::make_shared<DieselCar>(105,"Etios",1200,VehicleType::PERSONAL,40));

    data.emplace_back(std::make_shared<EvCar>(106,"Kona",2500,VehicleType::TRANSPORT,100));
    data.emplace_back(std::make_shared<EvCar>(107,"Nexon",1200,VehicleType::PERSONAL,70));

    data.emplace_back(std::make_shared<Hybrid>(108,"Vitara",1717,VehicleType::PERSONAL,123));
    data.emplace_back(std::make_shared<Hybrid>(109,"City",1100,VehicleType::PERSONAL,101));

    int id;
    std::string nm;
    float price;
    VehicleType type;
    int range;

    std::cout<<"Enter id: ";
    std::cin>>id;
    std::cout<<"\nEnter name: ";
    std::cin>>nm;
    std::cout<<"\nEnter price: ";
    std::cin>>price;
    std::cout<<"\nEnter category 0/1/2 : ";
    int choice;
    std::cin>>choice;
    switch (choice)
    {
    case 0:
        type=VehicleType::PERSONAL/* code */;
        break;
    case 1:
        type=VehicleType::SECURITY/* code */;
        break;
    case 2:
        type=VehicleType::TRANSPORT/* code */;
        break;
    
    default:
        break;
    }
    std::cout<<"\nEnter range or other things: ";
    std::cin>>range;
    
    data.emplace_back(std::make_shared<Hybrid>(id,nm,price,type,range));

    


}

float AveragePrice(Container &data)
{
    float total=0;

    for(int i=0;i<data.size();i++){
        std::cout<<'\n'<<*(data[i]);
        total=total+data[i]->getPrice();
    }
    return total/data.size();
}
