#include<iostream>
#include<vector>
#include "Functionalities.h"
int main()

{
    Container ptr;
    CreateObjects(ptr);
    std::cout<<"\nAverage price: "<<AveragePrice(ptr);
}