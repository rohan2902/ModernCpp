#include "Hybrid.h"

Hybrid::Hybrid(int id, std::string name, float price, VehicleType type, int capacity)
:Vehicle(id,name,price,type),_range(capacity)
{
}

Hybrid::Hybrid(int id, std::string name, VehicleType type, int capacity)
:Vehicle(id,name,type),_range(capacity)
{
}

std::ostream &operator<<(std::ostream &os, const Hybrid &rhs) {
    os << static_cast<const Vehicle &>(rhs)
       << " _range: " << rhs._range;
    return os;
}
