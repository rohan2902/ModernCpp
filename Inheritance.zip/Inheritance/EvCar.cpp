#include "EvCar.h"

EvCar::EvCar(int id, std::string name, float price, VehicleType type, int capacity)
:Vehicle(id,name,price,type),_wattage(capacity)
{
}

EvCar::EvCar(int id, std::string name, VehicleType type, int capacity)
:Vehicle(id,name,type),_wattage(capacity)
{
}

std::ostream &operator<<(std::ostream &os, const EvCar &rhs) {
    os << static_cast<const Vehicle &>(rhs)
       << " _wattage: " << rhs._wattage;
    return os;
}
