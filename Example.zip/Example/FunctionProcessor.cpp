#include "FunctionProcessor.h"

FunctionProcessor::FunctionProcessor(std::array<int, 3> &&data, const std::array<FnType, 3> &fns)
    : _data( data  ), _functions(fns)
{
}

void FunctionProcessor::operator()()
{
    for(const FnType& fn : _functions) {
        for(const int n : _data){
            fn (n);
        }
    }
}
