#include <iostream>
#include "Functionalities.h"

int main( ){
    
    StateContainer stateObjects;
    CreateObjects(stateObjects);
    ExecuteOperation(stateObjects);
}