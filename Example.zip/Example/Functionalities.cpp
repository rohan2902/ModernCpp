#include "Functionalities.h"
#include <iostream>

void CreateObjects(StateContainer &stateObjects)
{
    stateObjects.emplace_back(

        std::make_shared<FunctionProcessor>(
            
            std::array<int,3> {10,20,30},
            std::array<FnType,3> {
                [](int n1) { std::cout << n1 * n1 << "\n";},
                [](int n1) { std::cout << n1 * n1 * n1<< "\n";},
                [](int n1) { std::cout << n1 * 10 << "\n";}

            }
        )
    );


    stateObjects.emplace_back(
        std::make_shared<FunctionProcessor>(
            std::array<int,3> {50,60,70},
            std::array<FnType,3> {
                [](int n1) { std::cout << n1 * 100 << "\n";},
                [](int n1) { std::cout << n1 * n1 * 99<< "\n";},
                [](int n1) { std::cout << n1 * 50 << "\n";}

            }
        )
    );
}

void ExecuteOperation(const StateContainer &stateObjects)
{
    for(const Pointer& ptr : stateObjects) {
        (*ptr)();
    }
}
