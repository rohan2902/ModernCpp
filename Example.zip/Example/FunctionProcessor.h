#ifndef FUNCTIONPROCESSOR_H
#define FUNCTIONPROCESSOR_H

#include <array>
#include <functional>

using FnType = std::function<void(int)>;

class FunctionProcessor
{
private:
    std::array<int,3> _data;
    std::array<FnType,3> _functions ;
public:
    FunctionProcessor() = default;
    
    FunctionProcessor(const FunctionProcessor& ) = delete;
    FunctionProcessor(FunctionProcessor&&) = delete;
    
    FunctionProcessor& operator=(const FunctionProcessor&) = delete;
    FunctionProcessor& operator=(FunctionProcessor&&) = delete;

    FunctionProcessor(std::array<int,3>&& data, const std::array<FnType,3>& fns );
    
    void operator()();

    ~FunctionProcessor() = default;
};

#endif // FUNCTIONPROCESSOR_H
