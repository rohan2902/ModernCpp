#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include<list>
#include<iostream>
#include<functional>

extern std::function<void(const std::string&)>FindNonVowelChar;
extern std::function<int(const std::list<int>&)>SumOfOddNum;
extern std::function<float(const std::list<int>&)>AverageOfEven;
extern std::function<int(const std::list<int>)>SumOfSquares;
extern std::function<std::list<int>(const std::list<int>&)>ListOfNumDivisibleBy7;

#endif // FUNCTIONALITIES_H
