#include "Functionalities.h"

std::function<void(const std::string&)>FindNonVowelChar=[](const std::string& str){
    if(str.empty())
        throw std::runtime_error("\nInput string is empty"); // check for empty string
    bool flag=false;
    
    for(int i=0;i<str.size();i++){
        if(str[i]=='a'||str[i]=='e'||str[i]=='i'||str[i]=='o'||str[i]=='u'||
        str[i]=='A'||str[i]=='E'||str[i]=='I'||str[i]=='O'||str[i]=='U'){ //check for vowels
            
            continue;   //skip if its a vowel
        }
        else {
            flag=true;
            std::cout<<str[i]<<" ";
        }

    }
    if(!flag){
        throw std::runtime_error("\nNO single non-vowel character in string");
    }

};


std::function<int(const std::list<int>&l)>SumOfOddNum=[](const std::list<int>&l)
{
    if(l.empty())
        throw std::runtime_error("\nList is empty");
    int sum=0;
    for(int num:l){
        if(num%2!=0){
            sum+=num;
        }
    }
    if(sum==0){
        throw std::runtime_error("\nNo odd number found in list");
    
    }
    return sum;

};

std::function<float(const std::list<int>&)>AverageOfEven=[](const std::list<int>&EVenNums){
    float sum=0;
    int count=0;
    if(EVenNums.empty())
        throw std::runtime_error("\nList  is empty");
    
    for(int num:EVenNums){
        if(num%2==0){
            sum+=num;
            count++;

        }
    }
    if(sum==0)
        throw std::runtime_error("\nNo any even number in list");
    return sum/count;
};

std::function<int(const std::list<int>)>SumOfSquares=[](const std::list<int>&numbers){
    if(numbers.empty())
        throw std::runtime_error("\nList is empty");
    
    int sum=0;
    for(int num:numbers){
        if(num%2==0){
            sum+=(num*num);
        }
    }
    if(sum==0)
        throw std::runtime_error("\nNo even number in list found");
    return sum;
};

std::function<std::list<int>(const std::list<int>&)>ListOfNumDivisibleBy7=[](const std::list<int>&numbers){
    if(numbers.empty())
        throw std::runtime_error("\nList is empty");
    
    std::list<int> DivisibleBy7;    //empty list for answer
    for(int num:numbers)
        if(num%7==0)
            DivisibleBy7.emplace_back(num);
    
    if(DivisibleBy7.empty())
        throw std::runtime_error("\nNot a single number is divisible by 7");
    return DivisibleBy7;
};