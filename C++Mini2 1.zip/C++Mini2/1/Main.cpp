#include "Functionalities.h"

int main()
{   
    std::list <int> numbers{1,2,3,4,5,6,7,8,9,10};
    try
    {
        std::string str="Aman";
        std::cout<<"Non vowel characters: ";
        FindNonVowelChar(str);
        
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
    }
    try
    {
        std::cout<<"\nSum of odd numbers: " <<SumOfOddNum(numbers);
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    try
    {
        std::cout<<"\nAverage of even numners : "<<AverageOfEven(numbers);
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::cout<<"\nSum of squares of even numbers: "<<SumOfSquares(numbers);
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    try
    {
        std::list<int>DivisibleBy7=ListOfNumDivisibleBy7(numbers);
        std::cout<<"\nNumbers divisible by 7 : ";
        for(int num:DivisibleBy7)
            std::cout<<num<<" ";
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    

    
    
    
}