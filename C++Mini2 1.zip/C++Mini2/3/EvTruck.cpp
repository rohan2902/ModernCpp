#include "EvTruck.h"


std::ostream &operator<<(std::ostream &os, const EvTruck &rhs) {
    os << "batteryCapacity: " << rhs.batteryCapacity;
    return os;
}

EvTruck::EvTruck(std::string id, std::string name, float p, int i)
:Vehicle(id,name,p),batteryCapacity(i)
{
}

float EvTruck::CalculateRegistrationCharges()
{
    return 0.0;
}
