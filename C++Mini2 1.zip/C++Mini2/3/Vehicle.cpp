#include "Vehicle.h"


Vehicle::Vehicle(std::string id, std::string name, float p)
:vehicleId(id),manufacturerName(name),price(p)
{
}
std::ostream &operator<<(std::ostream &os, const Vehicle &rhs) {
    os << "vehicleId: " << rhs.vehicleId
       << " manufacturerName: " << rhs.manufacturerName
       << " price: " << rhs.price;
    return os;
}
