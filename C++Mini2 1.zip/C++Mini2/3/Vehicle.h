#ifndef VEHICLE_H
#define VEHICLE_H
#include<iostream>
class Vehicle
{
private:   
    std::string vehicleId;
    std::string manufacturerName;
    float price;

public:
Vehicle(std::string id,std::string name,float p );//PC
~Vehicle()=default;
Vehicle()=delete;
Vehicle(const Vehicle&)=delete;
Vehicle(Vehicle&&)=delete;
Vehicle& operator=(const Vehicle&)=delete;
Vehicle& operator=(Vehicle&&)=delete;

//getters
std::string getVehicleId() const { return vehicleId; }
std::string getManufacturerName() const { return manufacturerName; }
float getPrice() const { return price; }

//member functions
virtual float CalculateRegistrationCharges()=0;

friend std::ostream &operator<<(std::ostream &os, const Vehicle &rhs);

};

#endif // VEHICLE_H
