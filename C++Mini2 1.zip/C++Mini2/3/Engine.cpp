#include "Engine.h"

Engine::Engine(int i)
:horsePower(i)
{
}
std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "horsePower: " << rhs.horsePower;
    return os;
}
