#include "Vehicle.h"
#include "Car.h"
#include "EvTruck.h"
#include "Engine.h"
#include<memory>
#include<vector>

using Pointer=std::shared_ptr<Vehicle>;
using Container=std::vector<Pointer>;
using EngineContainer=std::vector<EnginePointer>;

void CreateObjects(Container&data,EngineContainer&engineData);
Pointer SearchById(const Container&data,std::string keyword);
int countInstances(const Container&data,std::string type);
float AveragePrice(const Container&data,std::string type);
Container ChargesBelow500(const Container&data);