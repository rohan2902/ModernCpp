#include "Functionalities.h"

int main()
{
    Container data;
    EngineContainer engineData;
    CreateObjects(data,engineData);

    try
    {
        Pointer ans=SearchById(data,"ID4");
        std::cout<<*ans<<'\n';
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
    }
    try
    {
        std::cout<<"Number of instances of EVTruck type : "<<countInstances(data,"EvTruck")<<'\n';
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        float average=AveragePrice(data,"Car");
        std::cout<<"Average price of car is: "<<average<<'\n';

    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
    }
    try
    {
        Container answer=ChargesBelow500(data);
        std::cout<<"Vehicles with tax between 0-5000 are\n";
        for(auto&ptr:answer){
            std::cout<<*ptr<<'\n';
        }
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
    }
    

    
    
    
}