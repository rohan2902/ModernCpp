#ifndef ENGINE_H
#define ENGINE_H
#include <ostream>

class Engine
{
private:
    int horsePower;
public:
    Engine()=delete;
    ~Engine()=default;
    Engine(int i);

    int getHorsePower() const { return horsePower; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);
};


#endif // ENGINE_H
