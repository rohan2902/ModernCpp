#include "Functionalities.h"

void CreateObjects(Container &data, EngineContainer &engineData)
{
    engineData.emplace_back(std::make_shared<Engine>(100));
    engineData.emplace_back(std::make_shared<Engine>(135));
    engineData.emplace_back(std::make_shared<Engine>(150));
    int choice;
    std::cout << "Enter choice: 1. Car 2. EvTruck: ";
    std::cin >> choice;
            std::string id;
            float price;
            int category;
            std::string name;
    switch (choice)
    {
    case 1:
            std::cin>>id;
            std::cin>>name;
            std::cin>>price;
            std::cout<<"\nChoose 1. Hatchbck 2. Sedan 3. SUV: ";
            std::cin>>category;
            CarCategory c;
            switch (category)
            {
            case 1:
                c=CarCategory::HATCHBACK;
                break;
            case 2:
                c=CarCategory::SEDAN;
                break;
            case 3:
                c=CarCategory::SUV;
                break;
            
            default:
                break;
            }
                        
        data.emplace_back(
            

            std::make_shared<Car>(id, name,price,engineData[0], c));
        break;

    case 2:
        data.emplace_back(
            std::make_shared<EvTruck>("ID4", "Tiago", 900000.1, 99));
        break;

    default:
        std::cout << "Wrong value entered\n";
        break;
    }

    data.emplace_back(
        std::make_shared<Car>("ID2", "DZire", 8000.1, engineData[1], CarCategory::SEDAN));
    data.emplace_back(
        std::make_shared<Car>("ID3", "Etios", 12000000.1, engineData[2], CarCategory::SUV));

    data.emplace_back(
        std::make_shared<EvTruck>("ID5", "V40", 4000000.1, 199));
    data.emplace_back(
        std::make_shared<EvTruck>("ID", "V90", 5000000.1, 209));
}

Pointer SearchById(const Container &data, std::string keyword)
{
    if (data.empty())
        throw std::runtime_error("\nData is empty");

    for (auto &ptr : data)
    {
        if (ptr->getVehicleId() == keyword)
            return ptr;
    }
    throw std::runtime_error("No data found");
}

int countInstances(const Container &data, std::string type)
{
    if (data.empty())
        throw std::runtime_error("\nDara empty");
    int count = 0;
    if (type == "Car" || type == "car")
    {
        for (auto &ptr : data)
        {
            if (auto ptrl = std::dynamic_pointer_cast<Car>(ptr))
                count++;
        }
    }
    if (type == "EvTruck")
    {
        for (auto &ptr : data)
        {
            if (auto ptrl = std::dynamic_pointer_cast<EvTruck>(ptr))
                count++;
        }
    }
    return count;
}

float AveragePrice(const Container &data, std::string type)
{
    if (data.empty())
        throw std::runtime_error("\nDara empty");
    int count = 0;
    float average = 0;
    if (type == "Car" || type == "car")
    {
        for (auto &ptr : data)
        {
            if (auto ptrl = std::dynamic_pointer_cast<Car>(ptr))
            {
                average += ptr->getPrice();
                count++;
            }
        }
    }
    if (type == "EvTruck")
    {
        for (auto &ptr : data)
        {
            if (auto ptrl = std::dynamic_pointer_cast<EvTruck>(ptr))
                average += ptr->getPrice();
            count++;
        }
    }
    return average / count;
}

Container ChargesBelow500(const Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("\nData empty");
    }
    Container answer;
    for (auto &ptr : data)
    {
        if (ptr->CalculateRegistrationCharges() > 0 && ptr->CalculateRegistrationCharges() < 5000)
        {
            std::cout << ptr->CalculateRegistrationCharges() << '\n';
            answer.emplace_back(ptr);
        }
    }
    if (answer.empty())
        throw std::runtime_error("No matching data found");

    return answer;
}
