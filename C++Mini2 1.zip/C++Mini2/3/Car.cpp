#include "Car.h"

Car::Car(std::string id,std::string name,float p, RefType type, CarCategory cat)
: Vehicle(id,name,p) , engine(type),category(cat)
{
}
float Car::CalculateRegistrationCharges()
{
    return 0.1*getPrice();
}
std::ostream &operator<<(std::ostream &os, const Car &rhs)
{
    os << "engine: " << rhs.engine.get()
       << " category: " <<static_cast<int> (rhs.category);
    return os;
}
