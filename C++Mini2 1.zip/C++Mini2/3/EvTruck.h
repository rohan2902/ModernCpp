#ifndef EVTRUCK_H
#define EVTRUCK_H
#include "Vehicle.h"
#include <ostream>
class EvTruck:public Vehicle
{
private:
    int batteryCapacity;
public:
EvTruck(std::string id,std::string name,float p,int i );

~EvTruck()=default;
EvTruck()=delete;
EvTruck(const EvTruck&)=delete;
EvTruck(EvTruck&&)=delete;
EvTruck& operator=(const EvTruck&)=delete;
EvTruck& operator=(EvTruck&&)=delete;
float CalculateRegistrationCharges();


friend std::ostream &operator<<(std::ostream &os, const EvTruck &rhs);
};

#endif // EVTRUCK_H
