#ifndef CAR_H
#define CAR_H
#include "Vehicle.h"
#include "CarCategory.h"
#include <functional>
#include "Engine.h"
#include <memory>
#include <ostream>
using EnginePointer=std::shared_ptr<Engine>;
using RefType=std::reference_wrapper<EnginePointer>;

class Car:public Vehicle
{
private:
    RefType engine;
    CarCategory category;

public:
Car(std::string id,std::string name,float p,RefType type,CarCategory cat );//PC
~Car()=default;
Car()=default;
Car(const Car&)=delete;
Car(Car&&)=delete;
Car& operator=(const Car&)=delete;
Car& operator=(Car&&)=delete;

RefType getEngine() const { return engine; }
CarCategory getCategory() const { return category; }

friend std::ostream &operator<<(std::ostream &os, const Car &rhs);

float CalculateRegistrationCharges();
};

#endif // CAR_H
