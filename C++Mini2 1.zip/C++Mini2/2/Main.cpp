#include "Functionalities.h"
using namespace std::placeholders;
int main()
{
    Container data;
    CreateObjects (data);
    try
    {
        std::cout<<"Number of cars with matching data: ";
        auto func1=std::bind(&CountCarsMatchingCondition,_1,12000);
        // std::cout<<func1(data);
        Operation1(func1,data);
        
        
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
    }
    try
    {
        Operation(AverageHorsePower,data);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    

    try
    {
        Operation(CombinedInsurance,data);
        // CombinedInsurance(data);
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        Operation(UniqueBrands,data);
        // UniqueBrands(data);
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
    }

    
    
    

}