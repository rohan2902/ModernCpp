#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include<functional>
#include<vector>
#include<memory>
#include"Cars.h"

using Pointer=std::shared_ptr<Cars>;
using Container=std::vector<Pointer>;

void CreateObjects(Container&data);
int CountCarsMatchingCondition(Container&data,int price);
void AverageHorsePower(const Container&data);
void CombinedInsurance (const Container&data);
void UniqueBrands(const Container&data);
void Operation(std::function<void(const Container&)>func,const Container&data);
void Operation1(std::function<int(Container&)>func1, Container&data);

#endif // FUNCTIONALITIES_H
