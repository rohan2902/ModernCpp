#include "Functionalities.h"

void CreateObjects(Container &data)
{
    // data.emplace_back(
    // std::make_shared<Cars> {"Acura","Integra",196818,16360,21500,100 }
    // );
    //   "Audi","A6",1878,23555,33950,200    "Audi","A8"
    // "Acura","RL",8588,29725,42000,210   "Audi","A4",20397,22255,23990,150
    data.emplace_back(
        std::make_shared<Cars>("Acura", "Integra", 16919, 16360, 21500, 100));
    data.emplace_back(
        std::make_shared<Cars>("Audi", "A6", 1878, 23555, 33950, 200));
    data.emplace_back(
        std::make_shared<Cars>("Acura", "RL", 8588, 29725, 42000, 210));
    data.emplace_back(
        std::make_shared<Cars>("Audi", "A4", 20397, 22255, 23990, 150));
    data.emplace_back(
        std::make_shared<Cars>("Audi", "A8", 138, 37000, 62000, 310));
    data.emplace_back(
        std::make_shared<Cars>("BMW", "323i", 19747, 20000, 26990, 170));
    data.emplace_back(
        std::make_shared<Cars>("BMW", "328i", 9231, 28676, 33400, 193));
    data.emplace_back(
        std::make_shared<Cars>("BMW", "528i", 17527, 36125, 38900, 193));
    data.emplace_back(
        std::make_shared<Cars>("Cadillac", "Escalade", 14785, 420000, 46225, 255));
    data.emplace_back(
        std::make_shared<Cars>("Cadillac", "Escalade", 14785, 420000, 46225, 255));
    data.emplace_back(
        std::make_shared<Cars>("Chevrolet", "Cavalier", 145519, 9250, 13260, 115));
    data.emplace_back(
        std::make_shared<Cars>("Chevrolet", "Cavalier", 145519, 9250, 13260, 115));
    
}

int CountCarsMatchingCondition(Container &data, int price)
{
    if (data.empty())
        throw std::runtime_error("\nContainer is empty");
    int count = 0;
    for (Pointer &ptr : data)
    {
        if (ptr->getHorsepower() > 100 && ptr->getPrice() > price)
            count++;
    }
    if (count == 0)
        throw std::runtime_error("\nNO such car found with matching conditions");
    std::cout<<"count"<<count<<'\n';
    return count;
}

void AverageHorsePower(const Container &data)
{
    if (data.empty())
        throw std::runtime_error("\nContainer is empty");

    float average = 0, count = 0;
    for (const Pointer &ptr : data)
    {
        if (ptr->getPrice() > 10000 && ptr->getManufacturer() != "Cadillac" && ptr->getManufacturer() != "Audi")
        {
            average += ptr->getHorsepower();
            count++;
        }
    }
    if (average == 0)
        throw std::runtime_error("\nNo condition matches ");
    std::cout << "\nAverage Horsepower: " << average / count;
}

void CombinedInsurance(const Container &data)
{
    if(data.empty())
        throw std::runtime_error("\nData is empty");
    float totalAmount=0;
    for(const Pointer&ptr:data){
        if(ptr->getManufacturer()=="BMW")
            totalAmount+=(ptr->getPrice()*(0.2));
        
        else
            totalAmount+=(ptr->getPrice()*(0.08));
    }

    std::cout<<"\nTotal combined Insurance amount of cars is: "<<totalAmount<<'\n';
}

void UniqueBrands(const Container &data)
{
    if(data.empty())
        throw std::runtime_error("\nData is empty");
    
    std::vector<std::string> uniqueBrands;
    bool flag=false;
    for(const Pointer&ptr:data){
        if(ptr->getHorsepower()>150 && ptr->getResaleValue()>25000){
            for(auto&str:uniqueBrands){
                if(ptr->getManufacturer()==str){
                    flag=true;
                    break;
                }
                    
            }
                if(!flag){

                    uniqueBrands.emplace_back(ptr->getManufacturer());

                }
                flag=false;
        }
    }
    std::cout<<"Unique car brands are: ";
    for(auto&str:uniqueBrands){
        std::cout<<str<<" ";
    }
}


void Operation(std::function<void(const Container& data)>func,const Container&data){
    func(data);
}

void Operation1(std::function<int(Container &)> func1,  Container &data)
{
    func1(data);  
}
