#include "Cars.h"

Cars::Cars(std::string manufac, std::string mod, int saleun, int resalev, int pri, int hp)
:manufacturer(manufac),model(mod),saleUnits(saleun),resaleValue(resalev),price(pri),horsepower(hp)
{
}
std::ostream &operator<<(std::ostream &os, const Cars &rhs) {
    os << "manufacturer: " << rhs.manufacturer
       << " model: " << rhs.model
       << " saleUnits: " << rhs.saleUnits
       << " resaleValue: " << rhs.resaleValue
       << " price: " << rhs.price
       << " horsepower: " << rhs.horsepower;
    return os;
}
