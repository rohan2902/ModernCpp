#ifndef CARS_H
#define CARS_H
#include<iostream>
class Cars
{
private:
    std::string manufacturer;
    std::string model;
    int saleUnits;      //camel case
    int resaleValue;
    int price;
    int horsepower;
public:
    Cars(std::string manufac,std::string mod,int saleun,int resalev,int pri,int hp); // Parameterzed constructor
    ~Cars() = default;
    Cars() = delete;
    Cars(const Cars &) = delete;
    Cars(Cars &&) = delete;
    Cars operator=(const Cars &) = delete;
    Cars operator=(Cars &&) = delete;


    //getters
    std::string getManufacturer() const { return manufacturer; }
    std::string getModel() const { return model; }
    int getSaleUnits() const { return saleUnits; }
    int getPrice() const { return price; }
    int getHorsepower() const { return horsepower; }
    int getResaleValue() const { return resaleValue; }

    friend std::ostream &operator<<(std::ostream &os, const Cars &rhs);
};

#endif // CARS_H
